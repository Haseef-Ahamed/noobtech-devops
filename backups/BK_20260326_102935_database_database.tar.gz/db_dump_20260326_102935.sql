-- MySQL Database Dump
-- Generated: 2026-03-26 10:29:35
-- Server: prod-db-01

CREATE DATABASE IF NOT EXISTS webapp;
USE webapp;
-- [Table data would be here in production]
-- users: 1,247 rows
-- orders: 8,432 rows
-- products: 356 rows
